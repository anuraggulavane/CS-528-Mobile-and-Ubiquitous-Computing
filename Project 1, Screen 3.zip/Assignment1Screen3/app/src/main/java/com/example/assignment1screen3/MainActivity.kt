package com.example.assignment1screen3

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button

class MainActivity : AppCompatActivity() {
    private lateinit var button: Button
    private lateinit var button2: Button
    private lateinit var button3: Button
    private lateinit var webview: WebView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button= findViewById(R.id.button)
        button2=findViewById(R.id.button2)
        button3=findViewById(R.id.button3)

        webview=findViewById(R.id.webview)

        webview.webViewClient= WebViewClient()
        webview.settings.javaScriptEnabled = true

        webview.loadUrl("https://google.com")

        button.setOnClickListener {
            webview.loadUrl("https://www.google.com")
        }

        button2.setOnClickListener {
            webview.loadUrl("https://pinterest.com")
        }

        button3.setOnClickListener {
            webview.loadUrl("https://youtube.com")
        }


        }
        }












































































































































