package com.example.assignment1screen2

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView

private var count1=0
private var count2=0
private var count3=0


private lateinit var imageview1: ImageView
private lateinit var imageview2: ImageView
private lateinit var imageview3: ImageView

private lateinit var textview1: TextView
private lateinit var textView2: TextView
private lateinit var textview3: TextView

@SuppressLint("MissingInflatedId")
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageview1= findViewById(R.id.imageView1)
        imageview2= findViewById(R.id.imageView2)
        imageview3= findViewById(R.id.imageView3)

        textview1= findViewById(R.id.textView1)
        textView2= findViewById(R.id.textView2)
        textview3= findViewById(R.id.textView3)

        imageview1.setOnClickListener(object: View.OnClickListener{
            override fun onClick(view: View?){
                count1++
                val display1 = "You have pressed picture 1 $count1 times"
                textview1.text=display1
            }

        })
        imageview2.setOnClickListener(object: View.OnClickListener {
            override fun onClick(view: View?) {
                count2++
                val display2 = "You have pressed picture 2 $count2 times"
                textView2.text = display2
            }
        })

        imageview3.setOnClickListener(object: View.OnClickListener {
            override fun onClick(view: View?) {
                count3++
                val display3 = "You have pressed picture 3 $count3 times"
                textview3.text = display3
            }
        })
    }
}